iHTML Shopping Cart - Integration Instructions
Last Revised: 08/17/2001

--------------------------------------------------------------------------------
Overview:

The enclosed files are designed to allow usage of our payment gateway with the iHTML Shopping Cart.  These files were originally written in the iHTML v2.1 language. (iHTML Manual v2.1 Enclosed)  These files have been designed to replace the existing basketX.html pages on your server.

These files are being provided AS IS.  This product & all related integration issues stemming from said integration, will not be supported or addressed by Plug & Pay Technologies, Inc or their respective partners.

--------------------------------------------------------------------------------

Terms & Conditions

By using these files you agree to the following; THESE FILES ARE BEING PROVIDED 'AS IS' & IN NO CASE SHALL PLUG & PAY TECHNOLOGIES, INC. AND/OR THEIR RESPECTIVE PARTNERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF SAID FILES, SOFTWARE, DOCUMENTS, PROVISION OF OR FAILURE TO PROVIDE SERVICES, OR INFORMATION AVAILABLE FROM THIS SERVER.  COPYING OR REPRODUCTION OF THESE FILES TO ANY OTHER SERVER OR LOCATION FOR FURTHER REPRODUCTION OR REDISTRIBUTION IS STRICTLY FORBIDDEN. 

--------------------------------------------------------------------------------

How To Integrate:

Integration is simple for the iHTML shopping cart.  Simply follow the below directions.

1 - Backup the following files on your server before starting.

  -- basket1.ihtml 
  -- basket2.ihtml 
  -- basket3.ihtml 
  -- basket4.ihtml 
  -- basket5.ihtml 
  -- basket6.ihtml 

* IMPORTANT NOTE: It is very important to backup your files before starting this integration process.  This is to prevent problems if things don't work correctly for your version of iHTML shopping cart.  Without your backups, there is no recourse if things go wrong.

2 - Upload the enclosed basketX.ihtml files & overwrite the copies contained on your server.

3 - Open the "backet5.html" file into a text editor (such as VI [under Unix/Linux] or Notepad [under Windows]).

4 - You will see the below code near the bottom of the page.

This code assumes, the merchant is not hosted on a secure server and we will be collecting the payment information.

A credit card authorization will be obtained by submitting a post with the defined variables below to the form action URL.  This will allow the consumer to enter the crdit card information securely.  The system will respond by calling the 'basket6.ihtml' URL as defined by the values submitted.  The system will do a remote POST to the script, passing it all variables collected as well as all variables passed to it with the exception of the credit card number.  

<form method=post action="https://{your-secure-payment-server-domain}/payment/{publisher-name}pay.cgi">
<input type="hidden" name="publisher-email" value="SALES@YOURDOMAIN.COM">
<input type="hidden" name="publisher-name" value="MERCHANT">
<input type="hidden" name="order-id" value="website-order">
<input type="hidden" name="easycart" value=1>
<input type="hidden" name="shipinfo" value=1>
<input type="hidden" name="card-allowed" value="Visa,Mastercard"> 
<input type="hidden" name="success-link" value="http://www.YOURDOMAIN.com/basket6.ihtml">
<input type="hidden" name="card-amount" value=":total">
<input type="hidden" name="shipping" value=":prodship">
<input type="hidden" name="tax" value=":tax1val">
<input type="hidden" name="custid" value=":custid">

5 - Edit the form field values as appropriate for your site. 

  "{your-secure-payment-server-domain}" is the domain of your secure payment gateway server.
    - In many cases, this will be "pay1.plugnpay.com".
    - If you have received a different secure payment gateway server domain, use it instead of the default. 

  "{publisher-name}" is the username issued to you by your secure payment gateway.

  "publisher-email" value is the email address where a copy of a sales confirmation notice will be sent.

  "publisher-name" value is the username issued to you by your secure payment gateway.

  "card-allowed" value is the type of credit cards you are allowed to accept online.
    - Valid credit card types are: "Visa", "Mastercard", "Amex", "Discover", "Diners", & "JCB"

  "success-link" value is a the URL in which the page will go upon a successful transaction.
    --> This needs to point to your web site's "basket6.ihtml" page.

  *** IMPORTANT *** 
  DO NOT CHANGE ANY OF THE OTHER VALUES UNLESS YOU ARE SURE IT WILL NOT AFFECT PROCESSING OF YOUR SECURE TRANSACTIONS.

6 - Your done... Set your secure payment gateway account in TEST mode and run several tests to ensure everything is working correctly.

Please remember these files are being provided AS IS.  This product & all related integration issues stemming from said integration would not be supported or addressed by Plug & Pay Technologies, Inc or their respective partners.

